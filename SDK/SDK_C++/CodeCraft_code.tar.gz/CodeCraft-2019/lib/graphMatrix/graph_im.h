#pragma once

 #include "graph_bfs.h"
// #include "graph_bfs_PU.h"
// #include "graph_dfs.h"
// #include "graph_dfs_PU.h"
// #include "graph_tsort.h"
// #include "graph_bcc.h"
// #include "graph_prim.h"
 #include "graph_dijkstra.h"
// #include "graph_pfs.h"
// #include "graph_prim_PU.h"
// #include "graph_dijkstra_PU.h"
