#!/bin/bash
sh build.sh
cd bin
./CodeCraft-2019 ../config/car.txt ../config/road.txt ../config/cross.txt ../config/answer.txt
./CodeCraft-2019 ../config_10/car.txt ../config_10/road.txt ../config_10/cross.txt ../config_10/answer.txt
./CodeCraft-2019 ../config_9/car.txt ../config_9/road.txt ../config_9/cross.txt ../config_9/answer.txt
./CodeCraft-2019 ../config_8/car.txt ../config_8/road.txt ../config_8/cross.txt ../config_8/answer.txt
./CodeCraft-2019 ../config_7/car.txt ../config_7/road.txt ../config_7/cross.txt ../config_7/answer.txt
./CodeCraft-2019 ../config_6/car.txt ../config_6/road.txt ../config_6/cross.txt ../config_6/answer.txt
./CodeCraft-2019 ../config_5/car.txt ../config_5/road.txt ../config_5/cross.txt ../config_5/answer.txt
./CodeCraft-2019 ../config_4/car.txt ../config_4/road.txt ../config_4/cross.txt ../config_4/answer.txt
./CodeCraft-2019 ../config_3/car.txt ../config_3/road.txt ../config_3/cross.txt ../config_3/answer.txt
./CodeCraft-2019 ../config_2/car.txt ../config_2/road.txt ../config_2/cross.txt ../config_2/answer.txt
./CodeCraft-2019 ../config_1/car.txt ../config_1/road.txt ../config_1/cross.txt ../config_1/answer.txt
